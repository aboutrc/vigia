/*
  # Update marker categories

  1. Changes
    - Update marker category constraint to allow 'ice' and 'police'
    - Add check constraint for valid categories
    - Update existing markers to use new categories

  2. Security
    - Maintain existing RLS policies
*/

-- Update the category check constraint
ALTER TABLE markers DROP CONSTRAINT IF EXISTS markers_category_check;
ALTER TABLE markers ADD CONSTRAINT markers_category_check 
  CHECK (category IN ('ice', 'police'));

-- Add index for category lookups
CREATE INDEX IF NOT EXISTS idx_markers_category ON markers(category);
/*
  # Update marker categories

  1. Changes
    - Update existing markers to use new categories
    - Add new category check constraint
    - Add index for category lookups

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  -- First update any existing rows to valid categories
  UPDATE markers 
  SET category = 'ice'
  WHERE category NOT IN ('ice', 'police');

  -- Then add the constraint
  IF EXISTS (
    SELECT 1 
    FROM information_schema.constraint_column_usage 
    WHERE constraint_name = 'markers_category_check'
  ) THEN
    ALTER TABLE markers DROP CONSTRAINT markers_category_check;
  END IF;

  ALTER TABLE markers ADD CONSTRAINT markers_category_check 
    CHECK (category IN ('ice', 'police'));
END $$;

-- Add index for category lookups if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_markers_category ON markers(category);
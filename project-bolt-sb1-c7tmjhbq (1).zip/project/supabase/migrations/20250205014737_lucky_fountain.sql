/*
  # Update marker categories and handle event_time

  1. Changes
    - Update existing markers to use new categories while preserving event_time
    - Add new category check constraint
    - Add index for category lookups

  2. Security
    - Maintain existing RLS policies
*/

-- First drop the event_time constraint temporarily
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'event_time_required_for_events'
  ) THEN
    ALTER TABLE markers DROP CONSTRAINT event_time_required_for_events;
  END IF;
END $$;

-- Update categories and handle event_time
UPDATE markers 
SET 
  category = 'ice',
  event_time = NULL
WHERE category NOT IN ('ice', 'police');

-- Add back the event_time constraint
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'event_time_required_for_events'
  ) THEN
    ALTER TABLE markers ADD CONSTRAINT event_time_required_for_events
      CHECK (
        (category = 'event' AND event_time IS NOT NULL) OR
        (category != 'event')
      );
  END IF;
END $$;

-- Update category constraint
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.constraint_column_usage 
    WHERE constraint_name = 'markers_category_check'
  ) THEN
    ALTER TABLE markers DROP CONSTRAINT markers_category_check;
  END IF;

  ALTER TABLE markers ADD CONSTRAINT markers_category_check 
    CHECK (category IN ('ice', 'police'));
END $$;

-- Add index for category lookups if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_markers_category ON markers(category);
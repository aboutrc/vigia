import React, { useState, useRef, useEffect } from 'react';
import { translations } from '../translations';
import EncounterPremadeButtons from './EncounterPremadeButtons';
import { Mic, Volume2, MicOff } from 'lucide-react';
import { useSpeechToText } from '../hooks/useSpeechToText';

interface EncounterProps {
  language?: 'en' | 'es';
}

const Encounter = ({ language = 'en' }: EncounterProps) => {
  const [error, setError] = useState<string | null>(null);
  const [englishText, setEnglishText] = useState('');
  const [spanishText, setSpanishText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const {
    isListening,
    transcript,
    error: speechError,
    hasPermission,
    startListening,
    stopListening,
    resetTranscript
  } = useSpeechToText({
    continuous: true,
    language: 'en-US'
  });

  const t = translations[language];

  // Translate text when transcript changes
  useEffect(() => {
    if (transcript) {
      setEnglishText(transcript);
      translateText(transcript);
    }
  }, [transcript]);

  const translateText = async (text: string) => {
    try {
      setIsTranslating(true);
      
      const response = await fetch(
        `https://translation.googleapis.com/language/translate/v2?key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            q: text,
            source: 'en',
            target: 'es',
            format: 'text'
          })
        }
      );

      if (!response.ok) {
        throw new Error('Translation failed');
      }

      const data = await response.json();
      setSpanishText(data.data.translations[0].translatedText);
    } catch (err) {
      console.error('Translation error:', err);
      setError('Translation failed. Please try again.');
    } finally {
      setIsTranslating(false);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      setError(null);
      startListening();
    }
  };

  useEffect(() => {
    if (speechError) {
      setError(speechError);
    }
  }, [speechError]);

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center p-4">
      <div className="w-full max-w-2xl">
        {/* Realtime Translation Section */}
        <div className="bg-black/30 backdrop-blur-sm rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-100 mb-4 flex items-center">
            {hasPermission === false ? <MicOff className="mr-2 text-red-500" /> : <Mic className="mr-2" />}
            ENGLISH TO SPANISH TRANSLATION
          </h2>

          {/* Waveform Visualization Area */}
          <div className="h-32 flex items-center justify-center bg-black/30 rounded-lg mb-4">
            {isListening ? (
              <div className="flex items-center space-x-1">
                {[...Array(20)].map((_, i) => (
                  <div
                    key={i}
                    className="w-1 bg-blue-500/50 rounded-full animate-soundbar"
                    style={{
                      height: '32px',
                      animationDelay: `${i * 0.1}s`
                    }}
                  />
                ))}
              </div>
            ) : (
              <div className="text-gray-500">
                {isProcessing ? (
                  <div className="text-blue-400">Processing speech...</div>
                ) : englishText || spanishText ? (
                  <div className="space-y-2">
                    <p className="text-gray-300">{englishText}</p>
                    <p className="text-gray-400">
                      {isTranslating ? 'Translating...' : spanishText}
                    </p>
                  </div>
                ) : hasPermission === false ? (
                  <div className="text-center space-y-2">
                    <p className="text-red-400">Microphone access is required</p>
                    <p className="text-sm">Please allow microphone access in your browser settings and reload the page</p>
                  </div>
                ) : (
                  <p>Click Record to start speaking in English...</p>
                )}
              </div>
            )}
          </div>

          {error && (
            <div className="bg-red-900/50 text-red-100 px-4 py-2 rounded-lg mb-4">
              {error}
            </div>
          )}

          {/* Record/Stop Button */}
          <div className="flex justify-center">
            <button
              onClick={toggleListening}
              disabled={isProcessing || hasPermission === false}
              className={`px-8 py-3 rounded-lg font-medium transition-colors ${
                isListening
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : hasPermission === false
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : isProcessing
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {hasPermission === false ? 'MICROPHONE BLOCKED' :
               isProcessing ? 'PROCESSING...' : 
               isListening ? 'STOP' : 'RECORD'}
            </button>
          </div>
        </div>

        {/* Premade Buttons Section */}
        <h2 className="text-xl font-semibold text-gray-100 mb-4 text-center">
          OR USE PRESET PHRASES
        </h2>

        <EncounterPremadeButtons speakerMode={true} />
      </div>
    </div>
  );
}

export default Encounter;
import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Scale } from 'lucide-react';
import { translations } from '../translations';

interface RightsSection {
  title: string;
  content: string[];
}

interface RightsProps {
  language?: 'en' | 'es';
}

const Rights = ({ language = 'en' }: RightsProps) => {
  const [expandedSections, setExpandedSections] = useState<number[]>([]);

  const t = translations[language];

  const sections: RightsSection[] = [
    {
      title: "The U.S. Constitution Protects Everyone",
      content: [
        "Everyone in the U.S. is Protected by the U.S. Constitution—Citizen or Not.",
        "The U.S. Constitution protects everyone that is physically in the U.S and is not meant for only citizens of the U.S.",
        "These rights ensure fair treatment for all."
      ]
    },
    {
      title: "Important Constitutional Amendments",
      content: [
        "Fifth Amendment:",
        "• Right to stay quiet if talking might get you in trouble",
        "• Everyone gets fair treatment by the law",
        "",
        "Fourth Amendment:",
        "• Police need a warrant, a judge's permission, to search you or your things",
        "• A warrant is different from an ICE order: A warrant comes from a judge, while an ICE order does not",
        "• Protects your privacy, including immigrants",
        "",
        "Fourteenth Amendment:",
        "• Everyone deserves fair legal processes",
        "• Laws must treat everyone equally, giving the same rights to all"
      ]
    },
    {
      title: "What Happens If ICE Comes to My Home",
      content: [
        "You have the right to remain silent and do not have to discuss your immigration status",
        "Ask if they have a warrant signed by a judge. If they don't, you can refuse to let them in",
        "Stay calm and keep the door closed",
        "If they have a valid warrant, you may have to let them in, but you still have the right to remain silent and consult a lawyer",
        "Do not sign any documents without speaking to an attorney"
      ]
    },
    {
      title: "What Happens If ICE Approaches Me on the Street",
      content: [
        "You have the right to remain silent and do not have to discuss your immigration status",
        "Ask if you are free to leave. If they say yes, calmly walk away",
        "You have the right to refuse to show identification or answer questions",
        "Remember, you do not have to sign any documents without speaking to an attorney"
      ]
    }
  ];

  const toggleSection = (index: number) => {
    setExpandedSections(current =>
      current.includes(index)
        ? current.filter(i => i !== index)
        : [...current, index]
    );
  };

  return (
    <div className="min-h-screen bg-gray-900 p-4">
      <div className="max-w-2xl mx-auto space-y-4">
        <div className="flex items-center space-x-2 text-gray-100 mb-6">
          <Scale size={24} />
          <h1 className="text-2xl font-semibold">Know Your Rights</h1>
        </div>

        {sections.map((section, index) => (
          <div
            key={index}
            className="bg-black/30 backdrop-blur-sm rounded-lg overflow-hidden"
          >
            <button
              onClick={() => toggleSection(index)}
              className="w-full px-4 py-3 flex items-center justify-between text-gray-100 hover:bg-black/40 transition-colors"
            >
              <span className="font-medium">{section.title}</span>
              {expandedSections.includes(index) ? (
                <ChevronDown size={20} />
              ) : (
                <ChevronRight size={20} />
              )}
            </button>
            
            {expandedSections.includes(index) && (
              <div className="px-4 pb-4">
                <div className="space-y-2 text-gray-300">
                  {section.content.map((item, i) => (
                    <div key={i} className="flex items-start">
                      {!item.startsWith('•') && item !== '' ? (
                        <>
                          <span className="mr-2">•</span>
                          <span>{item}</span>
                        </>
                      ) : (
                        <span className={item === '' ? 'py-1' : ''}>{item}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Rights;
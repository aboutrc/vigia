export const translations = {
  en: {
    title: 'VÍGIA',
    signOut: 'Sign Out',
    signIn: 'Sign In',
    addLocation: 'Add a Mark',
    clickToPlace: 'Click on map to place mark',
    showList: 'Show List',
    search: 'Search locations...',
    youAreHere: 'You are here',
    stillPresent: 'Still Present',
    resolved: 'Resolved',
    stillHere: 'Still Here',
    lastConfirmed: 'Last confirmed',
    locationSearch: {
      placeholder: 'Search by city, state or zip code...',
      error: 'Location search failed'
    },
    categories: {
      all: 'All Categories',
      ice: 'ICE',
      police: 'Police'
    },
    markerForm: {
      description: 'Description',
      category: 'Category',
      time: 'Event Time',
      save: 'Save',
      saving: 'Saving...',
      cancel: 'Cancel'
    },
    selectCategory: 'Select Category',
    noMarkers: 'No markers found',
    loading: 'Loading maps...',
    error: 'Error loading maps',
    viewAsGuest: 'View as Guest',
    createAccount: "Don't have an account? Sign up",
    haveAccount: 'Already have an account? Sign in',
    emailPlaceholder: 'Email address',
    passwordPlaceholder: 'Password',
    createAccountTitle: 'Create your account',
    signInTitle: 'Sign in to your account',
    rights: {
      title: 'Know Your Rights',
      section1: {
        title: 'Right to Remain Silent',
        content: [
          'You have the right to remain silent and not answer questions.',
          'If you wish to remain silent, say so out loud.',
          'Anything you say can be used against you.',
          'You have the right to talk to a lawyer before speaking to law enforcement.',
          'You can simply say "I want to speak to a lawyer."'
        ]
      },
      section2: {
        title: 'Rights at Your Home',
        content: [
          'You do not have to open your door unless officers have a warrant signed by a judge.',
          'Ask officers to slip the warrant under the door or hold it up to a window.',
          'Check that the warrant is signed and has the correct address.',
          'You have the right to remain silent even if officers have a warrant.',
          'You do not have to let officers in unless they have a warrant specifically authorizing entry.'
        ]
      },
      section3: {
        title: 'Rights in Public',
        content: [
          'You have the right to remain silent.',
          'You do not have to consent to a search of yourself or your belongings.',
          'If you are not under arrest, you have the right to calmly walk away.',
          'You have the right to record law enforcement officers in public.',
          'Keep a safe distance and do not interfere with police activities.'
        ]
      },
      section4: {
        title: 'If You Are Arrested',
        content: [
          'Do not resist arrest, even if you believe the arrest is unfair.',
          'Say you wish to remain silent and ask for a lawyer immediately.',
          'Do not give any explanations or excuses.',
          'Do not say anything, sign anything, or make any decisions without a lawyer.',
          'You have the right to make a local phone call.'
        ]
      }
    },
    errors: {
      fetchMarkers: 'Unable to load markers. Please try again later.',
      location: 'Unable to get your location.',
      general: 'Something went wrong. Please try again.',
      auth: 'Please sign in to perform this action.',
      duplicate: 'This marker already exists.',
      translation: 'Translation failed. Please try again.',
      audio: {
        load: 'Failed to load audio files. Please try again later.',
        play: 'Failed to play audio. Please try again.',
        recognition: 'Error with speech recognition. Please try again.',
        notSupported: 'Speech recognition is not supported in your browser.',
        recording: 'Error accessing microphone. Please check permissions.',
        processing: 'Error processing audio. Please try again.'
      }
    },
    encounter: {
      title: 'Real-time Translation',
      listening: 'Listening...',
      pressListen: 'Press the microphone button to start listening',
      startListening: 'Start Listening',
      stopListening: 'Stop Listening',
      speak: 'Speak Translation',
      loading: 'Loading...',
      playSound: 'Play Sound',
      stopSound: 'Stop Sound',
      recordMessage: 'Record your message',
      startRecording: 'Start Recording',
      stopRecording: 'Stop Recording',
      generateSpeech: 'Generate Speech',
      processing: 'Processing...'
    }
  },
  es: {
    title: 'VÍGIA',
    signOut: 'Cerrar Sesión',
    signIn: 'Iniciar Sesión',
    addLocation: 'Agregar Marca',
    clickToPlace: 'Haz clic en el mapa para colocar la marca',
    showList: 'Mostrar Lista',
    search: 'Buscar ubicaciones...',
    youAreHere: 'Estás aquí',
    stillPresent: 'Aún Presente',
    resolved: 'Resuelto',
    stillHere: '¿Sigue Aquí?',
    lastConfirmed: 'Última confirmación',
    locationSearch: {
      placeholder: 'Buscar por ciudad, estado o código postal...',
      error: 'Búsqueda de ubicación fallida'
    },
    categories: {
      all: 'Todas las Categorías',
      ice: 'ICE',
      police: 'Policía'
    },
    markerForm: {
      description: 'Descripción',
      category: 'Categoría',
      time: 'Hora del Evento',
      save: 'Guardar',
      saving: 'Guardando...',
      cancel: 'Cancelar'
    },
    selectCategory: 'Seleccionar Categoría',
    noMarkers: 'No se encontraron marcadores',
    loading: 'Cargando mapas...',
    error: 'Error al cargar mapas',
    viewAsGuest: 'Ver como Invitado',
    createAccount: '¿No tienes cuenta? Regístrate',
    haveAccount: '¿Ya tienes cuenta? Inicia sesión',
    emailPlaceholder: 'Correo electrónico',
    passwordPlaceholder: 'Contraseña',
    createAccountTitle: 'Crea tu cuenta',
    signInTitle: 'Inicia sesión en tu cuenta',
    rights: {
      title: 'Conoce Tus Derechos',
      section1: {
        title: 'Derecho a Guardar Silencio',
        content: [
          'Tienes derecho a guardar silencio y no responder preguntas.',
          'Si deseas guardar silencio, dilo en voz alta.',
          'Todo lo que digas puede ser usado en tu contra.',
          'Tienes derecho a hablar con un abogado antes de hablar con la policía.',
          'Simplemente puedes decir "Quiero hablar con un abogado."'
        ]
      },
      section2: {
        title: 'Derechos en Tu Casa',
        content: [
          'No tienes que abrir la puerta a menos que los oficiales tengan una orden judicial firmada por un juez.',
          'Pide a los oficiales que pasen la orden por debajo de la puerta o que la muestren por la ventana.',
          'Verifica que la orden esté firmada y tenga la dirección correcta.',
          'Tienes derecho a guardar silencio incluso si los oficiales tienen una orden.',
          'No tienes que dejar entrar a los oficiales a menos que tengan una orden que específicamente autorice la entrada.'
        ]
      },
      section3: {
        title: 'Derechos en Público',
        content: [
          'Tienes derecho a guardar silencio.',
          'No tienes que consentir a un registro de tu persona o tus pertenencias.',
          'Si no estás bajo arresto, tienes derecho a alejarte calmadamente.',
          'Tienes derecho a grabar a los oficiales de la ley en público.',
          'Mantén una distancia segura y no interfieras con las actividades policiales.'
        ]
      },
      section4: {
        title: 'Si Eres Arrestado',
        content: [
          'No resistas el arresto, incluso si crees que es injusto.',
          'Di que deseas guardar silencio y pide un abogado inmediatamente.',
          'No des explicaciones ni excusas.',
          'No digas nada, no firmes nada, ni tomes decisiones sin un abogado.',
          'Tienes derecho a hacer una llamada telefónica local.'
        ]
      }
    },
    errors: {
      fetchMarkers: 'No se pudieron cargar los marcadores. Por favor, inténtalo de nuevo más tarde.',
      location: 'No se pudo obtener tu ubicación.',
      general: 'Algo salió mal. Por favor, inténtalo de nuevo.',
      auth: 'Por favor, inicia sesión para realizar esta acción.',
      duplicate: 'Este marcador ya existe.',
      translation: 'Error en la traducción. Por favor, inténtalo de nuevo.',
      audio: {
        load: 'Error al cargar los archivos de audio. Por favor, inténtalo de nuevo más tarde.',
        play: 'Error al reproducir el audio. Por favor, inténtalo de nuevo.',
        recognition: 'Error con el reconocimiento de voz. Por favor, inténtalo de nuevo.',
        notSupported: 'El reconocimiento de voz no está soportado en tu navegador.',
        recording: 'Error al acceder al micrófono. Por favor, verifica los permisos.',
        processing: 'Error al procesar el audio. Por favor, inténtalo de nuevo.'
      }
    },
    encounter: {
      title: 'Traducción en Tiempo Real',
      listening: 'Escuchando...',
      pressListen: 'Presiona el botón del micrófono para comenzar a escuchar',
      startListening: 'Comenzar a Escuchar',
      stopListening: 'Dejar de Escuchar',
      speak: 'Hablar Traducción',
      loading: 'Cargando...',
      playSound: 'Reproducir Sonido',
      stopSound: 'Detener Sonido',
      recordMessage: 'Graba tu mensaje',
      startRecording: 'Comenzar Grabación',
      stopRecording: 'Detener Grabación',
      generateSpeech: 'Generar Voz',
      processing: 'Procesando...'
    }
  }
};
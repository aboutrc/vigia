import { useState, useEffect, useRef } from 'react';

interface UseSpeechToTextOptions {
  continuous?: boolean;
  interimResults?: boolean;
  language?: string;
}

export function useSpeechToText(options: UseSpeechToTextOptions = {}) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const recognitionRef = useRef<any>(null);
  const noSpeechTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setError('Speech recognition is not supported in your browser.');
      return;
    }

    const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
    recognitionRef.current = new SpeechRecognition();

    const recognition = recognitionRef.current;
    recognition.continuous = options.continuous ?? true;
    recognition.interimResults = options.interimResults ?? true;
    recognition.lang = options.language ?? 'en-US';

    recognition.onstart = () => {
      // Reset error when starting new recognition
      setError(null);
      
      // Clear any existing timeout
      if (noSpeechTimeoutRef.current) {
        window.clearTimeout(noSpeechTimeoutRef.current);
      }
      
      // Set a timeout to check for no speech
      noSpeechTimeoutRef.current = window.setTimeout(() => {
        if (isListening && !transcript) {
          setError('No speech detected. Please try speaking again.');
          stopListening();
        }
      }, 10000); // 10 seconds timeout
    };

    recognition.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript + ' ';
        } else {
          interimTranscript += transcript;
        }
      }

      // Clear no-speech timeout when we get results
      if (noSpeechTimeoutRef.current) {
        window.clearTimeout(noSpeechTimeoutRef.current);
        noSpeechTimeoutRef.current = null;
      }

      setTranscript(finalTranscript || interimTranscript);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      
      if (event.error === 'not-allowed') {
        setHasPermission(false);
        setError('Microphone access was denied. Please allow microphone access in your browser settings and try again.');
      } else if (event.error === 'audio-capture') {
        setError('No microphone found. Please connect a microphone and try again.');
      } else if (event.error === 'no-speech') {
        // Don't set error for no-speech as we handle it with the timeout
        return;
      } else {
        setError('Speech recognition error. Please try again.');
      }
      
      setIsListening(false);
    };

    recognition.onend = () => {
      // Clear no-speech timeout
      if (noSpeechTimeoutRef.current) {
        window.clearTimeout(noSpeechTimeoutRef.current);
        noSpeechTimeoutRef.current = null;
      }

      if (isListening && hasPermission !== false) {
        try {
          recognition.start();
        } catch (err) {
          console.error('Restart recognition error:', err);
        }
      }
    };

    return () => {
      if (recognition) {
        recognition.stop();
      }
      if (noSpeechTimeoutRef.current) {
        window.clearTimeout(noSpeechTimeoutRef.current);
      }
    };
  }, [options.continuous, options.interimResults, options.language, isListening, hasPermission, transcript]);

  const checkMicrophonePermission = async (): Promise<boolean> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      setHasPermission(true);
      setError(null);
      return true;
    } catch (err: any) {
      console.error('Microphone permission error:', err);
      setHasPermission(false);
      
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('Microphone access was denied. Please allow microphone access in your browser settings and try again.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setError('No microphone found. Please connect a microphone and try again.');
      } else {
        setError('Unable to access microphone. Please check your device settings.');
      }
      
      return false;
    }
  };

  const startListening = async () => {
    setError(null);
    
    if (recognitionRef.current && !isListening) {
      // Check microphone permission first
      const hasAccess = await checkMicrophonePermission();
      if (!hasAccess) return;

      try {
        await recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Start recognition error:', err);
        setError('Failed to start speech recognition. Please try again.');
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
    
    // Clear no-speech timeout
    if (noSpeechTimeoutRef.current) {
      window.clearTimeout(noSpeechTimeoutRef.current);
      noSpeechTimeoutRef.current = null;
    }
  };

  return {
    isListening,
    transcript,
    error,
    hasPermission,
    startListening,
    stopListening,
    resetTranscript: () => setTranscript(''),
  };
}